<?php


namespace Drupal\charts\Services;


interface ChartsSettingsServiceInterface {

  public function getChartsSettings();
}