<?php

namespace Drupal\charts_google\Settings\Google;

class VerticalAxis {
  private $title;

}
